module.exports = blockName => `
const $ = window.$;
export default () => {
};
`;