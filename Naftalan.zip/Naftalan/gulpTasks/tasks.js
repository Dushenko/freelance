module.exports = [
  './gulpTasks/deploy.js',
  './gulpTasks/images.js',
  './gulpTasks/libs.js',
  './gulpTasks/pug.js',
  './gulpTasks/sass.js',
  './gulpTasks/script.js',
  './gulpTasks/watch.js'
];